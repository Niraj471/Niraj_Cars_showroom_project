from django.shortcuts import render
from .services import CarServices

def home(request):
    return render(request,'index.html')

def home1(request):
    return render(request,'ad_panel.html')

def home2(request):
    return render(request,'serch.html')

def Admin_search(request):
        request.method=="POST"
        no=int(request.POST.get("user_id"))
        obj=CarServices()
        data=obj.search_user(no)

        if data =='pass':
              return render(request,"ad_panel.html")
        else:
              return render(request,"failed.html")


def search_by_company(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.searchresult_cmp(cmp)
        return render(request,"search_by_cmp.html",{"user":'Niraj',"carlist":data})
    

def type_c(request):
    return render(request,'search_by_type.html')

def search_by_type_c(request):
    if request.method=="POST":
        typ=request.POST.get("carType")
        obj=CarServices()
        data=obj.searchresult_type(typ)
        return render(request,"search_by_type_result.html",{"user":'Niraj',"carlist":data})
    
def list_of_car(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.list_car()
        return render(request,"search_by_cmp.html",{"user":'Niraj',"carlist":data})
    

def list_of_cst(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.list_cst()
        return render(request,"lst_of_customer.html",{"user":'Niraj',"customerlist":data})

def new_ca(request):
    return render(request,'new_car.html')   

def addcar(request):
    
    if request.method=="POST":
        no=int(request.POST.get("car_id"))
        co=request.POST.get("company")
        no_cm=0
        pr=int(request.POST.get("price"))
        mo=request.POST.get("model")
        no_ct=0
        ct=request.POST.get("car_type")
        fl=int(request.POST.get("fuel_capacity"))

        obj=CarServices()
        stat=obj.add_c(no,co,no_cm,pr,mo,no_ct,ct,fl)
        if stat=="success":
            page="RegDone.html"
        else:
            page="failedr.html"
    
    return render(request,page)

def new_cst(request):
    return render(request,'new_customer.html')
    

def addcst(request):
    
    if request.method=="POST":
        no=int(request.POST.get("customer_id"))
        nm=request.POST.get("customer_name")
        cp=request.POST.get("car_purchased")
        obj=CarServices()
        stat=obj.add_cs(no,nm,cp)
        if stat=="success":
            page="RegDone.html"
        else:
            page="failedr.html"
    
    return render(request,page)

def search_by_car_id(request):
    return render(request,'search_by_id.html')

def search_id_c(request):
    if request.method=="POST":
        no=int(request.POST.get("car_id"))
        obj=CarServices()
        data=obj.searchresult_id(no)
        return render(request,"search_by_id_result.html",data)

def search_by_cst_id(request):
    return render(request,'search_cst_by_id.html')

def search_id_cst(request):
    if request.method=="POST":
        no=int(request.POST.get("customer_id"))
        obj=CarServices()
        data=obj.searchresult_id_cst(no)
        return render(request,"search_cst_by_id_result.html",data)
    
def change(request):
    return render(request,"update_car_price.html")

def changeprice(request):
    if request.method=="POST":
        no=int(request.POST.get("car_id"))
        pri=int(request.POST.get("new_price"))
        obj=CarServices()
        status=obj.changecarprice(no,pri)
        return render(request,"update_status.html",{'status':status})               

def change_cst(request):
    return render(request,"update_cst_detail.html")

def changenamecst(request):
    if request.method=="POST":
        no=int(request.POST.get("customer_id"))
        nm=request.POST.get("new_name")
        obj=CarServices()
        status=obj.changecstname(no,nm)
        return render(request,"update_status.html",{'status':status}) 

def car_log(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.car_serch_log()
        return render(request,"car_search_log.html",{"user":'Niraj',"carlist":data})
    
def mst_cmp(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.mst_ser_cmp()
        return render(request,"most_ser_cmp.html",{"user":'Niraj',"carlist":data})
    
def mst_car(request):
    if request.method=="POST":
        cmp=request.POST.get("company")
        obj=CarServices()
        data=obj.mst_ser_car()
        return render(request,"most_ser_car.html",{"user":'Niraj',"carlist":data})
    



                  

          
              




       
       
       
          
