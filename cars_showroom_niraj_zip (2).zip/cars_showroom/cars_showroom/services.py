import pymysql

class CarServices:
     
     def search_user(self,no):

        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select * from user where user_id=%d" %no)
        data=curs.fetchone()
        pob={}

        if data:
                pob='pass'
            
        else:
                pob='fail'
            
        con.close()
        return pob
     
     def searchresult_cmp(self,cmp):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        try:
             curs.execute("UPDATE cars SET no_cmp_serch = no_cmp_serch + 1 WHERE company='%s'" %cmp)
             con.commit()

             curs.execute("select * from cars where company='%s'" %cmp)
             data=curs.fetchall()
             return data
        
        except mysql.connector.Error as err:
             print("Error:",err)

     def searchresult_type(self,typ):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        try:
             curs.execute("UPDATE cars SET no_car_serch = no_car_serch + 1 WHERE car_type='%s'" %typ)
             con.commit()

             curs.execute("select * from cars where car_type='%s'" %typ)
             data=curs.fetchall()
             return data
        
        except mysql.connector.Error as err:
             print("Error:",err)


     def list_car(self):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select * from cars ")
        data=curs.fetchall()
        return data
     
     def list_cst(self):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select * from customers ")
        data=curs.fetchall()
        return data
     
     def add_c(self,no,co,no_cm,pr,mo,no_ct,ct,fl):
        try:
            con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
            curs=con.cursor()
            curs.execute("insert into cars values(%d,'%s',%d,%d,'%s',%d,'%s',%d)" %(no,co,no_cm,pr,mo,no_ct,ct,fl))
            con.commit()
            stat="success"
        except:
            stat="failed"
        
        return stat
     
     def add_cs(self,no,nm,cp):
        try:
            con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
            curs=con.cursor()
            curs.execute("insert into customers values(%d,'%s','%s')" %(no,nm,cp))
            con.commit()
            stat="success"
        except:
            stat="failed"
        
        return stat
     
     def searchresult_id(self,no):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select * from cars where car_id=%d" %no)
        data=curs.fetchone()
        mob={}

        if data:
            mob['car_id']=data[0]
            mob['company']=data[1]
            mob['no_cmp_serch']=data[2]
            mob['price']=data[3]
            mob['model']=data[4]
            mob['no_car_serch']=data[5]
            mob['car_type']=data[6]
            mob['fuel_capacity']=data[7]
        else:
            mob['car_id']='not found'
            mob['company']='not found'
            mob['no_cmp_serch']=0
            mob['price']=0
            mob['model']='not found'
            mob['no_car_serch']=0
            mob['car_type']='not found'
            mob['fuel_capacity']=0
        con.close()
        return mob
     

     def searchresult_id_cst(self,no):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select * from customers where customer_id=%d" %no)
        data=curs.fetchone()
        mob={}

        if data:
            mob['customer_id']=data[0]
            mob['customer_name']=data[1]
            mob['car_purchased']=data[2]
            
        else:
            mob['customer_id']='not found'
            mob['customer_name']='not found'
            mob['car_purchased']='not found'
            
        con.close()
        return mob
     
     def changecarprice(self,no,pri):
        try:
            con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
            curs=con.cursor()
            curs.execute("update cars set price=%d where car_id=%d" %(pri,no))
            con.commit()
            status='success'
        except:
            status='failed'
        
        return status
     
     def changecstname(self,no,nm):
        try:
            con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
            curs=con.cursor()
            curs.execute("update customers set customer_name='%s' where customer_id=%d" %(nm,no))
            con.commit()
            status='success'
        except:
            status='failed'
        
        return status
     

     def car_serch_log(self):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select car_id,company,no_cmp_serch,car_type,no_car_serch,model from cars ")
        data=curs.fetchall()
        return data
     
     def mst_ser_cmp(self):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select car_id, company, no_cmp_serch,model from cars order by no_cmp_serch desc limit 5 ")
        data=curs.fetchall()
        return data
     
     def mst_ser_car(self):
        con=pymysql.connect(host="bhm6wd2vlrdejidb2g18-mysql.services.clever-cloud.com",user="ushto2wrfddbo4p9",password="Pbgwq4J9o1UoxwyInWDX",database="bhm6wd2vlrdejidb2g18")
        curs=con.cursor()
        curs.execute("select car_id,company, car_type, no_car_serch,model from cars order by no_car_serch desc limit 5 ")
        data=curs.fetchall()
        return data
        


     

