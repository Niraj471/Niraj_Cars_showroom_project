"""
URL configuration for cars_showroom project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('car/',views.home),
    path('panel/',views.home1),
    path('search/',views.home2),
    path('admin_login/',views.Admin_search),
    path('search_cmp/',views.search_by_company),
    path('search_car_type/',views.type_c),
    path('search_type_c/',views.search_by_type_c),
    path('lst_c/',views.list_of_car),
    path('list_cst/',views.list_of_cst),
    path('register_car/',views.new_ca),
    path('adcar/',views.addcar),
    path('register_customer/',views.new_cst),
    path('adcustomer/',views.addcst),
    path('search_car/',views.search_by_car_id),
    path('carsearch/',views.search_id_c),
    path('search_customer/',views.search_by_cst_id),
    path('customersearch/',views.search_id_cst),
    path('update_car_price/',views.change),
    path('changepri/',views.changeprice),
    path('update_customer_detail/',views.change_cst),
    path('updatecustomer/',views.changenamecst),
    path('car_lg/',views.car_log),
    path('mst_cp/',views.mst_cmp),
    path('mst_ca/',views.mst_car),
    
    
]
